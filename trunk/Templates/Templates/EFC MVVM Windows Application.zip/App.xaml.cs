﻿// //----------------------------------------------------------------------------
// // <copyright company="Experion Global P Ltd" file ="App.xaml.cs">
// // All rights reserved Copyright 2012-2013 Experion Global
// // This computer program may not be used, copied, distributed, corrected, modified,
// // translated, transmitted or assigned without Experion Global's prior written authorization
// // </copyright>
// // <summary>
// // The <see cref="App.xaml.cs"/> file.
// // </summary>
// //---------------------------------------------------------------------------------------------
using System.Windows;
using GalaSoft.MvvmLight.Threading;

namespace $safeprojectname$
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        static App()
        {
            DispatcherHelper.Initialize();
        }
    }
}
