﻿// //----------------------------------------------------------------------------
// // <copyright company="Experion Global P Ltd" file ="ViewModelLocator.cs">
// // All rights reserved Copyright 2012-2013 Experion Global
// // This computer program may not be used, copied, distributed, corrected, modified,
// // translated, transmitted or assigned without Experion Global's prior written authorization
// // </copyright>
// // <summary>
// // The <see cref="ViewModelLocator.cs"/> file.
// // </summary>
// //---------------------------------------------------------------------------------------------
using System.Configuration;
using Microsoft.Practices.ServiceLocation;
using Microsoft.Practices.Unity;
using Microsoft.Practices.Unity.Configuration;

namespace $safeprojectname$.ViewModels
{
    /// <summary>
    /// This class contains static references to all the view models in the
    /// application and provides an entry point for the bindings.
    /// <para>
    /// See http://www.galasoft.ch/mvvm
    /// </para>
    /// </summary>
    public class ViewModelLocator
    {
        private static UnityContainer parentUnityContainer;

        protected static IUnityContainer ChildContainer { get; set; }

        static ViewModelLocator()
        {
            BuildContainer();

            var locator = new UnityServiceLocator(ChildContainer);

            ServiceLocator.SetLocatorProvider(() => locator);
        }

        /// <summary>
        /// Gets the Main property.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance",
            "CA1822:MarkMembersAsStatic",
            Justification = "This non-static member is needed for data binding purposes.")]
        public MainViewModel Main
        {
            get
            {
                return ChildContainer.Resolve<MainViewModel>();
            }
        }

        /// <summary>
        /// Gets the customer.
        /// </summary>
        /// <value>
        /// The customer.
        /// </value>
        public CustomerViewModel Customer
        {
            get
            {
                return ChildContainer.Resolve<CustomerViewModel>();
            }
        }

        /// <summary>
        /// Builds the parentUnityContainer.
        /// </summary>
        private static void BuildContainer()
        {
            var unityContainerParent = new UnityContainer();
            parentUnityContainer = unityContainerParent;

            BuildChildContainer();
        }

        /// <summary>
        /// Builds the child parentUnityContainer.
        /// </summary>
        private static void BuildChildContainer()
        {
            ChildContainer = parentUnityContainer.CreateChildContainer();

            var section = LoadUnityConfigurationFile();
            section.Configure(ChildContainer, "parent");
            parentUnityContainer.RegisterInstance("child", ChildContainer);


            RegisterTypes();
          
        }

        /// <summary>
        /// Loads the unity configuration file.
        /// </summary>
        /// <returns>Unity Configuration Section</returns>
        private static UnityConfigurationSection LoadUnityConfigurationFile()
        {
            var section = (UnityConfigurationSection)ConfigurationManager.GetSection("unity");
            return section;
        }

        /// <summary>
        /// Registers the types.
        /// </summary>
        private static void RegisterTypes()
        {
            ChildContainer.RegisterInstance(typeof(IUnityContainer), ChildContainer);

            ChildContainer.RegisterType<CustomerView>("CustomerView");
            ChildContainer.RegisterType<CustomerViewModel>(new InjectionProperty("View", ChildContainer.Resolve<CustomerView>("CustomerView")));
        }

        /// <summary>
        /// Cleans up all the resources.
        /// </summary>
        public static void Cleanup()
        {
        }
    }
}