﻿// //----------------------------------------------------------------------------
// // <copyright company="Experion Global P Ltd" file ="CustomerViewModel.cs">
// // All rights reserved Copyright 2012-2013 Experion Global
// // This computer program may not be used, copied, distributed, corrected, modified,
// // translated, transmitted or assigned without Experion Global's prior written authorization
// // </copyright>
// // <summary>
// // The <see cref="CustomerViewModel.cs"/> file.
// // </summary>
// //---------------------------------------------------------------------------------------------
using System;
using System.Collections.ObjectModel;
using Experion.Client.Common.Base;
using Microsoft.Practices.Unity;
using $safeprojectname$.Model;

namespace $safeprojectname$.ViewModels
{
    /// <summary>
    /// CustomerViewModel.
    /// </summary>
    public class CustomerViewModel : ViewModel<CustomerModel>
    {

        /// <summary>
        /// Initializes a new instance of the CustomerViewModel class.
        /// </summary>
        public CustomerViewModel(IUnityContainer container, CustomerModel model)
            : base(model, container)
        {
            model.Category = "EFC Sample";
            model.CustomerId = Guid.NewGuid();
            model.CustomerName = "EFC";

            model.Customers = new ObservableCollection<CustomerModel> { model, model, model, model };
        }
    }
}