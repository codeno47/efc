﻿// //----------------------------------------------------------------------------
// // <copyright company="Experion Global P Ltd" file ="CustomerModel.cs">
// // All rights reserved Copyright 2012-2013 Experion Global
// // This computer program may not be used, copied, distributed, corrected, modified,
// // translated, transmitted or assigned without Experion Global's prior written authorization
// // </copyright>
// // <summary>
// // The <see cref="CustomerModel.cs"/> file.
// // </summary>
// //---------------------------------------------------------------------------------------------
using System;
using System.Collections.ObjectModel;
using Experion.Client.Common.Base;

namespace $safeprojectname$.Model
{
    /// <summary>
    /// CustomerModel.
    /// </summary>
    public class CustomerModel:ModelBase
    {
        /// <summary>
        /// The customer name
        /// </summary>
        private string customerName;

        /// <summary>
        /// The customer id
        /// </summary>
        private Guid customerId;

        /// <summary>
        /// The category
        /// </summary>
        private string category;

        #region Properties

        /// <summary>
        /// Gets or sets the name of the customer.
        /// </summary>
        /// <value>
        /// The name of the customer.
        /// </value>
        public string CustomerName
        {
            get { return customerName; }
            set
            {
                customerName = value;
                RaisePropertyChanged("CustomerName");
            }
        }

        /// <summary>
        /// Gets or sets the customers.
        /// </summary>
        /// <value>
        /// The customers.
        /// </value>
        public ObservableCollection<CustomerModel> Customers { get; set; }

        /// <summary>
        /// Gets or sets the customer id.
        /// </summary>
        /// <value>
        /// The customer id.
        /// </value>
        public Guid CustomerId
        {
            get { return customerId; }
            set
            {
                customerId = value;
                RaisePropertyChanged("CustomerId");
            }
        }

        /// <summary>
        /// Gets or sets the category.
        /// </summary>
        /// <value>
        /// The category.
        /// </value>
        public string Category
        {
            get { return category; }
            set
            {
                category = value;
                RaisePropertyChanged("Category");
            }
        }

        #endregion
    }
}
