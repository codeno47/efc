﻿// //----------------------------------------------------------------------------
// // <copyright company="Experion Global P Ltd" file ="CustomerView.xaml.cs">
// // All rights reserved Copyright 2012-2013 Experion Global
// // This computer program may not be used, copied, distributed, corrected, modified,
// // translated, transmitted or assigned without Experion Global's prior written authorization
// // </copyright>
// // <summary>
// // The <see cref="CustomerView.xaml.cs"/> file.
// // </summary>
// //---------------------------------------------------------------------------------------------
using System.Windows;
using System.Windows.Controls;

namespace $safeprojectname$
{
    /// <summary>
    /// Description for CustomerView.
    /// </summary>
    public partial class CustomerView : UserControl
    {
        /// <summary>
        /// Initializes a new instance of the CustomerView class.
        /// </summary>
        public CustomerView()
        {
            InitializeComponent();
        }
    }
}