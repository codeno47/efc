﻿using System;

using Microsoft.Practices.Unity;

namespace $rootnamespace$
{
    using EFC.Common.Service;

    /// <summary>
    /// Business Service
    /// </summary>
    public class $safeitemname$ : BusinessService
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="$safeitemname$"/> class.
        /// </summary>
        /// <param name="unity">The unity.</param>
        public $safeitemname$(IUnityContainer unity)
            : base(unity)
        {
        }

        public override int Save()
        {
            throw new NotImplementedException();
        }

        public override void Dispose()
        {
            throw new NotImplementedException();
        }
    }
}
