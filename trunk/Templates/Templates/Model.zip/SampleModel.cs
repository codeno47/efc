﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Experion.Client.Common.Base;

namespace $rootnamespace$
{
    /// <summary>
    /// $safeitemname$
    /// </summary>
    public class $safeitemname$ : ModelBase
    {
    }
}
