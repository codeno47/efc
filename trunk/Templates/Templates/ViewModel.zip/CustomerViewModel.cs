﻿// //----------------------------------------------------------------------------
// // <copyright company="Experion Global P Ltd" file ="$safeitemname$.cs">
// // All rights reserved Copyright 2012-2013 Experion Global
// // This computer program may not be used, copied, distributed, corrected, modified,
// // translated, transmitted or assigned without Experion Global's prior written authorization
// // </copyright>
// // <summary>
// // The <see cref="$safeitemname$.cs"/> file.
// // </summary>
// //---------------------------------------------------------------------------------------------
using System;
using System.Collections.ObjectModel;
using Experion.Client.Common.Base;
using Microsoft.Practices.Unity;
using MvvmLightSample.Model;

namespace $rootnamespace$
{
    /// <summary>
    /// $safeitemname$.
    /// </summary>
    public class $safeitemname$ : ViewModel<CustomerModel>
    {

        /// <summary>
        /// Initializes a new instance of the $safeitemname$ class.
        /// </summary>
        public $safeitemname$(IUnityContainer container, CustomerModel model)
            : base(model, container)
        {
            model.Category = "EFC Sample";
            model.CustomerId = Guid.NewGuid();
            model.CustomerName = "EFC";

            model.Customers = new ObservableCollection<CustomerModel> { model, model, model, model };
        }
    }
}